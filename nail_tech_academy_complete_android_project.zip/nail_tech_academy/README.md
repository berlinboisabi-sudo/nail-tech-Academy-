# Nail Tech Academy — Android project

**Project version:** 0.4.0 (Android wrapper + branded icon + cloud-build workflow)  
**Package ID:** `com.nailtechacademy.app`  
**Minimum Android:** Android 7.0 (API 24) or newer

Nail Tech Academy is a mobile-first nail-tech learning prototype focused on practicing service steps, learning from mistakes, inclusive brown skin tones, and building a local portfolio.

## What's included

- Android app shell that opens the bundled app offline in a WebView
- Custom Nail Tech Academy icon and launcher icon resources, including adaptive icon support
- Plum, rose, and gold brand artwork; icon also appears in the app header
- Guided practice stages: sanitation/inspection, prep, shaping, base coat, colour, top coat
- Intentional practice errors (flooded cuticle, uneven layer, wrong shape) and correction feedback
- XP and level progression
- Real nail-work photo upload and guided self-assessment rubric
- Local portfolio and portfolio summary export
- Full-Service Studio for hand and foot service stages, selectable brown skin tones, and hygiene checklists
- Android photo picker support
- GitHub Actions workflow that builds a debug APK and publishes it as a downloadable workflow artifact

## Important current limitations

- This is an early prototype. The hand/foot and nail models are stylized 2D illustrations, not a true interactive 3D simulation.
- Photo assessment is a guided self-assessment rubric. It does not automatically inspect the image with AI or replace instructor feedback.
- Progress and portfolio data are stored locally on this device. There are no user accounts, cloud sync, or automatic backup.
- Photos can use significant local storage; export/backup your work before clearing app data or uninstalling.
- Service checklists are educational prompts. Follow product manufacturer instructions, infection-prevention training, and applicable local rules. Do not perform scrubs/massage on irritated, broken, infected, or otherwise unsuitable skin.
- The APK has not been compiled or tested in this workspace. The cloud workflow is provided to build it.

## Build an APK using the included cloud workflow

This repository contains `.github/workflows/android-apk.yml`. After you upload the project to a GitHub repository:

1. Open the repository on GitHub and select **Actions**.
2. Select **Build Nail Tech Academy APK**.
3. Press **Run workflow** (or push a commit to the `main` branch).
4. Open the completed workflow run.
5. Under **Artifacts**, download `nail-tech-academy-debug-apk` and extract `app-debug.apk`.
6. Transfer the APK to your Android phone, open it, and approve Android's install-from-this-source prompt if shown.

This creates a **debug/testing APK** for personal testing, not a signed Play Store release. You do not need to publish the app on Google Play to install a debug APK. Only download/build from a repository you control.

## Build locally in Android Studio

1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as an existing project and let Gradle sync.
3. Use JDK 17 and Gradle 8.9 (the Android Gradle Plugin is 8.7.3).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Test the generated APK on a real phone, especially image upload, local persistence, scrolling, and back navigation.

## Before a public release

- Add a proper interactive 3D engine and legally licensed 3D assets if desired.
- Test accessibility, privacy, data deletion, device compatibility, and app performance.
- Consider persistent storage migration and an export/import backup flow.
- Implement any AI photo critique transparently, with user consent, clear privacy information, and cost controls.
- Create a private release signing key and keep it backed up securely. Never commit signing keys or passwords to source control.
- Complete Google Play's current testing, data-safety, content-rating, and developer verification requirements.
