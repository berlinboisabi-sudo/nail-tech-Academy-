# Build the APK from your phone

You do **not** need to publish the app on the Play Store. The included GitHub Actions workflow can build a testing APK in the cloud. You will need a GitHub account and must upload this project to a repository you control.

1. Create a new repository on GitHub. If you want to keep the project private, choose **Private**.
2. Upload the files and folders from this project, keeping hidden folders such as `.github/workflows` (the workflow file is what triggers the build).
3. On GitHub, open the repository's **Actions** tab and enable Actions if asked.
4. Choose **Build Nail Tech Academy APK** → **Run workflow**.
5. When it finishes successfully, open the run and download the `nail-tech-academy-debug-apk` artifact.
6. Extract `app-debug.apk` from the downloaded ZIP and open it on your Android phone.
7. If Android asks, allow installation from the app you used to open the APK, then continue installation.

If the build fails, open the workflow run and check the first red error. Do not download an APK from a repository you do not trust.
